<?php

namespace App;

use Illuminate\Database\Eloquent\Model;



class OrderTag extends Model
{
	
}
